# Logistic_Multinomial
 Web Logistic Multinomial Machine Learning
